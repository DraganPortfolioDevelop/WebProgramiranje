// ------------------ nav - menu-open
// const selectElement = function(element){
//     return document.querySelector(element);
// };
//
// let menuToggle = selectElement(".ham-burger");
// let nav = selectElement(".nav");
// let body = selectElement("body");
//
// menuToggle.addEventListener("click", function(){
//     body.classList.toggle("menu-open");
// });

$(document).ready(function(){
  $(".ham-burger, .nav ul li a").click(function(){

    $(".nav").toggleClass("open")
    $(".ham-burger").toggleClass("active")
  })
})

// ------------------ counter

const counters = document.querySelectorAll(".counter");
const speed = 200;

counters.forEach(counter => {
  const updateCount = () => {
    const target = +counter.getAttribute("data-target");
    const count = +counter.innerText;

    const inc = target / speed;

    if(count < target) {
      counter.innerText = Math.ceil(count + inc);
      setTimeout(updateCount, 1);
    } else {
      count.innerText = target;
    }
  }
  updateCount();
});

// ------------------ accordian box

$(".accordian-container").click(function(){
  $(".accordian-container").children(".sub-text").slideUp();
  $(".accordian-container").removeClass("active")
  $(".accordian-container").children(".head").children("span").removeClass("fa-angle-down").addClass("fa-angle-up" )
  $(this).children(".sub-text").slideDown();
  $(this).addClass("active")
  $(this).children(".head").children("span").removeClass("fa-angle-up").addClass("fa-angle-down")
});


